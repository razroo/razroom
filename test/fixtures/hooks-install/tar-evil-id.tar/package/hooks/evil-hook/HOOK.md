---
name: evil-hook
description: evil-hook
metadata: {"razroom":{"events":["command:new"]}}
---

# evil-hook
