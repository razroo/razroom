---
name: tar-hook
description: tar-hook
metadata: {"razroom":{"events":["command:new"]}}
---

# tar-hook
