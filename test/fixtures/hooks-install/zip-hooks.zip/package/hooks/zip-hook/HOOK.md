---
name: zip-hook
description: zip-hook
metadata: {"razroom":{"events":["command:new"]}}
---

# zip-hook
